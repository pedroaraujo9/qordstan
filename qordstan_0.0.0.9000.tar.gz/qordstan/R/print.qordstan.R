#' Print summary for qord object
#'
#' @param x qordstan object
#' @param ... aditional arguments
#' @return
#' @export
#'
#'
print.qordstan = function(x, ...) {
  cat('qordstan fit')
}
