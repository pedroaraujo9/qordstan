library(testthat)
library(qordstan)

test_check("qordstan")
